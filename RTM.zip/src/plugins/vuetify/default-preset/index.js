const { VuetifyPresetService } = require('@vuetify/cli-plugin-utils')

module.exports = api => VuetifyPresetService(api, 'master')
