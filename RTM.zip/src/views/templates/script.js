var AudioContext = window.AudioContext // Default
    || window.webkitAudioContext // Safari and old versions of Chrome
    || false; 

function getAverageVolume(array) {
	var values = 0;
	var average;
	var length = array.length;
	// get all the frequency amplitudes
	for (var i = 0; i < length; i++) {
		values += array[i];
	}
	average = values / length;
	return average;
}

function setupVolumeMeter(videoElement, canvasElement, height) {
	var context = new AudioContext();
	var sourceNode = context.createMediaElementSource(videoElement)
	var javascriptNode = context.createScriptProcessor(8192, 1, 1);
	var analyser = context.createAnalyser();

	analyser.smoothingTimeConstant = 0.4;
	analyser.fftSize = 1024;

	javascriptNode.connect(context.destination);
	analyser.connect(javascriptNode);
	sourceNode.connect(analyser);
	
	//To connect to speakers
	//sourceNode.connect(context.destination);
	
	var ctx = canvasElement.getContext("2d");
	javascriptNode.onaudioprocess = function() {
		// get the average, bincount is fftsize / 2
		var array =  new Uint8Array(analyser.frequencyBinCount);
		analyser.getByteFrequencyData(array);
		var average = getAverageVolume(array)
		
		var grd=ctx.createLinearGradient(0,0,0,height);
		grd.addColorStop(1,"green");
		grd.addColorStop(0.4,"yellow");
		grd.addColorStop(0.2,"red");
		grd.addColorStop(0,"red");
		
		// clear the current state
		ctx.clearRect(0, 0, 35, height);

		// set the fill style
		ctx.fillStyle=grd;

		// create the meters
		ctx.fillRect(0,height-height*average/100,35,height*average/100);
	}
}
