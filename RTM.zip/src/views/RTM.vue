<template>
  <v-app>
    <v-main>
      <v-btn
        :z-index="1001"
        class="mt-10"
        fab
        plain
        color="primary"
        top
        right
        large
        absolute
        @click="newStart"
      >
        <v-icon x-large>{{ icons.mdiCloseThick }}</v-icon>
      </v-btn>
      <v-container fill-height fluid class="ma-0">
        <v-row align="center" justify="center">
          <v-col cols="12" class="pa-0">
            <div class="text-center" v-if="!loaded">
              <v-progress-circular
                :size="120"
                color="primary"
                indeterminate
              ></v-progress-circular>
            </div>
            <!-- Select menu+play button -->
            <v-row align="center" justify="center" v-if="loaded">
              <v-col cols="8" class="pa-0">
                <v-row align="center" justify="center">
                  <v-select
                    v-if="!startFeed"
                    v-model="selectedStreams"
                    :menu-props="{ top: true, offsetY: true }"
                    :items="serverList"
                    item-text="description"
                    item-value="id"
                    attach
                    chips
                    label="Select Streams"
                    multiple
                  ></v-select>
                </v-row>
                <v-row align="center" justify="center">
                  <v-btn
                    v-if="!startFeed"
                    v-bind="startFeed"
                    large
                    class="mx-5 my-4"
                    color="primary"
                    :disabled="selectedStreams.length == 0"
                    @click="loadFeed"
                  >
                    Play
                  </v-btn>
                </v-row>
              </v-col>
            </v-row>
            <!-- End Select menu+play button -->

            <!-- Janus Video -->
            <div id="PlayersArea" class="mainMV">
              <div
                class="vidContianer"
                :key="i"
                v-for="(camera, i) in tempCameras"
              >
                <div class="vidDiv">
                  <!-- <h3>{{ camera.id }}</h3> -->
                  <v-snackbar
                    :timeout="-1"
                    :value="true"
                    style="position: absolute"
                    centered
                    top
                    tile
                    min-width="25"
                    color="rgba(113, 27, 205, 0.75)"
                    elevation="24"
                    v-if="overlayOn"
                  >
                    <h2>
                      {{
                        overlayList[
                          overlayList.findIndex((object) => {
                            return object.id === camera.id;
                          })
                        ].info.description
                      }}
                    </h2>
                    <!-- <h3>
                    {{
                      overlayList[
                        overlayList.findIndex((object) => {
                          return object.id === camera.id;
                        })
                      ].info.metadata
                    }}
                  </h3> -->
                  </v-snackbar>
                  <video
                    :id="`liveCam${i}`"
                    class="live-video"
                    playsinline
                    autoplay
                    muted
                    @click="playAudio(`liveCam${i}`)"
                  ></video>
                  <v-snackbar
                    :timeout="-1"
                    :value="true"
                    style="position: absolute"
                    color="rgba(113, 27, 205, 0)"
                    elevation="24"
                    min-width="50"
                    left
                  >
                    <div
                      :id="`audioBarsCanvas${i}`"
                      style="margin: 0px 10px"
                    ></div>
                  </v-snackbar>
                </div>
              </div>
            </div>
            <!-- End Jasnus -->
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
import Janus from "./janus";
import { mdiCloseThick } from "@mdi/js";

export default {
  mounted() {
    document.title = "Real Time Monitor";
    this.initJanus();
    window.setTimeout(() => {
      this.checkJanusList();
      console.log("Loaded!");
    }, 500);

    window.setInterval(() => {
      this.overlayInfo();
      // console.log("overlay info");
    }, 5000);
    this.pickList();
  },
  beforeDestroy() {
    this.janus.destroy();
  },
  setup() {
    return {
      icons: { mdiCloseThick },
    };
  },
  data() {
    return {
      janus: { type: Object },
      streaming: [],
      cameras: [],
      tempCameras: [],
      serverList: [],
      overlayList: [],
      overlayOn: false,
      watchID: " ",
      selectedStreams: [],
      startFeed: false,
      camCount: null,
      loaded: false,
    };
  },
  watch: {},
  computed: {},
  created() {},
  methods: {
    initJanus() {
      this.loading = true;
      // test server
      let server = "https://janus.conf.meetecho.com/janus";

      Janus.init({
        callback: () => {
          this.janus = new Janus({
            server,
            success: () => {
              this.loading = false;
            },
            error: (cause) => {
              console.log(cause);
            },
            destroyed: () => {
              console.log("janus init destroyed");
            },
          });
        },
      });
    },
    loadFeed() {
      this.startFeed = true;
      this.selectedStreams.forEach((s) => {
        this.tempCameras.push({ id: s, play: false });
      });
      // make a cookieList to store your picked list temprary locally.
      document.cookie = "cookieList" + "=" + this.selectedStreams;
      document.cookie = "oldcookieList" + "=" + this.selectedStreams;
      // console.log(this.selectedStreams);
      this.mvResize();
      this.playCameras();
      window.setTimeout(() => {
        this.overlayOn = true;
      }, 1500);
    },
    playAudio(live) {
      if (document.getElementById(live).muted == false) {
        document.getElementById(live).muted = true;
      } else document.getElementById(live).muted = false;
    },
    checkJanusList() {
      this.janus.attach({
        opaqueId: "test",
        plugin: "janus.plugin.streaming",
        success: (pluginHandle) => {
          if (pluginHandle) {
            let body = { request: "list" };
            pluginHandle.send({
              message: body,
              success: (result) => {
                this.serverList = result.list;
                // console.log(this.serverList);
                this.serverList.forEach((element) => {
                  if (this.watchID != null) {
                    if (element.description.search(this.watchID) > -1) {
                      if (this.cameras.indexOf(element.id) === -1) {
                        this.cameras.push(element.id);
                      }
                    }
                  }
                });
                // console.log(this.cameras);
              },
            });
          }
        },
      });
      this.loaded = true;
    },
    // playing live streams via (tempCameras) avoid problems with auto play policy
    playCameras() {
      for (let i = 0; i < this.tempCameras.length; i++) {
        if (this.tempCameras[i].play == false) {
          this.janus.attach({
            opaqueId: "test-" + i,
            plugin: "janus.plugin.streaming",
            detached: () => {
              console.log("cleaning!");
            },
            success: (pluginHandle) => {
              if (pluginHandle) {
                this.streaming.push({ id: i, plugin: pluginHandle });
                let body = { request: "watch", id: this.tempCameras[i].id };
                pluginHandle.send({ message: body });
              }
            },
            error: (error) => {
              console.log(error);
            },
            onmessage: (msg, jsep) => {
              if (jsep !== undefined && jsep !== null) {
                const foundStream = this.streaming.find((s) => s.id === i);
                if (jsep.type === "offer") {
                  foundStream.plugin.createAnswer({
                    jsep,
                    media: { audioSend: false, videoSend: false },
                    success: function (jsep) {
                      const body = { request: "start" };
                      foundStream.plugin.send({ message: body, jsep: jsep });
                    },
                    error: function (error) {
                      Janus.error("WebRTC error:", error);
                    },
                  });
                }
              }
            },
            onremotestream: (stream) => {
              const element = document.getElementById(`liveCam${i}`);
              Janus.attachMediaStream(element, stream);
              const elementAudio = document.getElementById(
                `audioBarsCanvas${i}`
              );
              Janus.attachMediaStream(elementAudio, stream);
              this.visualize(i, stream, element.getBoundingClientRect().height);
              this.tempCameras[i].play = true;
              this.overlayList.push({
                id: this.tempCameras[i].id,
                info: "getting info",
              });
            },
          });
        }
      }
    },
    overlayInfo() {
      for (let i = 0; i < this.tempCameras.length; i++) {
        if (this.tempCameras[i].play == true) {
          this.janus.attach({
            opaqueId: "test-" + i,
            plugin: "janus.plugin.streaming",
            detached: () => {
              console.log("cleaning!");
            },
            success: (pluginHandle) => {
              if (pluginHandle) {
                let body = { request: "info", id: this.tempCameras[i].id };
                pluginHandle.send({
                  message: body,
                  success: (result) => {
                    var searchIndex = this.overlayList.findIndex(
                      (stream) => stream.id == this.tempCameras[i].id
                    );
                    this.overlayList[searchIndex].info = result.info;
                  },
                });
              }
            },
            error: (error) => {
              console.log(error);
              if (error == "Is the gateway down? (connected=false)") {
                window.location.reload();
                this.loadFeed();
              }
            },
          });
        }
      }
    },
    showOverlay(streamID) {
      var searchIndex = this.overlayList.findIndex(
        () => streamID == this.overlayList.id
      );
      if (searchIndex != -1) {
        console.log(this.overlayList[searchIndex].info);
        return this.overlayList[searchIndex].info;
      }
    },
    // trying to make audio bars here for audio feedback per live source
    visualize(id, mediaStream, frameHeight) {
      // The number of bars that should be displayed
      const NBR_OF_BARS = 2;

      // Create an audio context
      const ctx = new AudioContext();

      // Create an audio source
      const audioSource = ctx.createMediaStreamSource(mediaStream);

      // Create an audio analyzer
      const analayzer = ctx.createAnalyser();
      analayzer.fftSize = 1024;
      // Connect the source, to the analyzer, and then back the the context's destination
      audioSource.connect(analayzer);
      // audioSource.connect(ctx.destination);

      // Print the analyze frequencies
      const frequencyData = new Uint8Array(analayzer.frequencyBinCount);
      analayzer.getByteFrequencyData(frequencyData);

      // Get the visualizer container
      const visualizerContainer = document.getElementById(
        `audioBarsCanvas${id}`
      );

      // Create a set of pre-defined bars
      for (let i = 0; i < NBR_OF_BARS; i++) {
        const bar = document.createElement("DIV");
        bar.setAttribute("id", `bar${id}` + i);
        bar.setAttribute("class", "visualizer-container__bar");
        visualizerContainer.appendChild(bar);
      }

      // This function has the task to adjust the bar heights according to the frequency data
      function renderFrame() {
        //throttle requestAnimationFrame to 20fps
        // Update our frequency data array with the latest frequency data
        analayzer.getByteFrequencyData(frequencyData);
        for (let i = 0; i < NBR_OF_BARS; i++) {
          // Since the frequency data array is 1024 in length, we don't want to fetch
          // the first NBR_OF_BARS of values, but try and grab frequencies over the whole spectrum
          const index = i + 64;
          // fd is a frequency value between 0 and 255
          const fd = ((frequencyData[index] / 50) * frameHeight) / 2.5;

          // Fetch the bar DIV element
          const bar = document.querySelector(`#bar${id}` + i);

          if (!bar) {
            continue;
          }

          // If fd is undefined, default to 0, then make sure fd is at least 4
          // This will make make a quiet frequency at least 4px high for visual effects
          const barHeight = Math.max(5, fd || 0);
          bar.style.height = barHeight + "px";
          if (barHeight >= 0 && barHeight < (frameHeight * 5) / 100) {
            bar.style.background = `linear-gradient(
                0deg,
                rgba(0, 0, 0, 1) 0%,
                rgba(69, 182, 75, 1) 100%
              )`;
          } else if (
            barHeight >= (frameHeight * 5) / 100 &&
            barHeight < (frameHeight * 80) / 100
          ) {
            bar.style.background = `linear-gradient(
                0deg,
                rgba(0, 0, 0, 1) 0%,
                rgba(69, 182, 75, 1) 5%,
                rgba(106, 255, 0, 1) 100%
                )`;
          } else if (
            barHeight >= (frameHeight * 80) / 100 &&
            barHeight < (frameHeight * 95) / 100
          ) {
            bar.style.background = `linear-gradient(
                0deg,
                rgba(0, 0, 0, 1) 0%,
                rgba(69, 182, 75, 1) 3%,
                rgba(106, 255, 0, 1) 85%,
                rgba(255, 254, 0, 1) 100%
              )`;
          } else {
            bar.style.background = `linear-gradient(
                0deg,
                rgba(0, 0, 0, 1) 0%,
                rgba(69, 182, 75, 1) 2%,
                rgba(106, 255, 0, 1) 80%,
                rgba(255, 254, 0, 1) 95%,
                rgba(255, 0, 0, 1)  100%
              )`;
          }
        }

        // At the next animation frame, call ourselves
        window.requestAnimationFrame(renderFrame);
      }
      window.requestAnimationFrame(renderFrame);
    },
    // VisualizesetupVolumeMeter(videoElement, canvasElement, height) {
    //   var context = new AudioContext();
    //   var audioSource = context.createMediaElementSource(videoElement);
    //   var javascriptNode = context.createScriptProcessor(8192, 1, 1);
    //   var analyser = context.createAnalyser();
    //   analyser.smoothingTimeConstant = 0.4;
    //   analyser.fftSize = 1024;
    //   javascriptNode.connect(context.destination);
    //   analyser.connect(javascriptNode);
    //   audioSource.connect(analyser);
    //   //To connect to speakers
    //   //audioSource.connect(context.destination);
    //   var ctx = canvasElement.getContext("2d");
    //   function getAverageVolume(array) {
    //     var values = 0;
    //     var average;

    //     var length = array.length;

    //     // get all the frequency amplitudes
    //     for (var i = 0; i < length; i++) {
    //       values += array[i];
    //     }

    //     average = values / length;
    //     return average;
    //   }
    //   javascriptNode.onaudioprocess = function () {
    //     console.log(analyser.frequencyBinCount);
    //     // get the average, bincount is fftsize/2;
    //     var array = new Uint8Array(analyser.frequencyBinCount);
    //     analyser.getByteFrequencyData(array);
    //     var average = getAverageVolume(array);
    //     // var average = 1;
    //     var grd = ctx.createLinearGradient(0, 0, 0, height);
    //     grd.addColorStop(1, "green");
    //     grd.addColorStop(0.4, "yellow");
    //     grd.addColorStop(0.2, "red");
    //     grd.addColorStop(0, "red");
    //     //clear the current state
    //     ctx.clearRect(0, 0, 100, height);
    //     // set the fill style
    //     ctx.fillStyle = grd;
    //     // create the meters
    //     ctx.fillRect(
    //       10,
    //       10,
    //       height - (((height * average) / (100.35).height) * average) / 100,
    //       height - (((height * average) / (100.35).height) * average) / 100
    //     );
    //   };
    // },
    mvResize() {
      //resize video resolution depending on count of windows
      // 1x1
      if (this.selectedStreams.length < 2) {
        document.getElementById("PlayersArea").classList.add("mainMV1x1");
      }
      // 1x2
      if (this.selectedStreams.length == 2) {
        document.getElementById("PlayersArea").classList.add("mainMV1x2");
      }
      // 2x2
      if (this.selectedStreams.length > 2 && this.selectedStreams.length < 5) {
        document.getElementById("PlayersArea").classList.add("mainMV2x2");
      }
      // 2x3
      if (this.selectedStreams.length > 4 && this.selectedStreams.length < 7) {
        document.getElementById("PlayersArea").classList.add("mainMV2x3");
      }
      // 3x3
      if (this.selectedStreams.length > 6 && this.selectedStreams.length < 10) {
        document.getElementById("PlayersArea").classList.add("mainMV3x3");
        // document.body.style.zoom = "67%";
      }
      // 3x4
      if (this.selectedStreams.length > 9 && this.selectedStreams.length < 13) {
        document.getElementById("PlayersArea").classList.add("mainMV3x4");
      }
      // 4x4
      if (this.selectedStreams.length > 12) {
        document.getElementById("PlayersArea").classList.add("mainMV4x4");
        // document.body.style.zoom = "135%";
      }
      setTimeout(function () {
        var vc = document.getElementById("PlayersArea").firstChild;
        var hh = vc.getBoundingClientRect().height;
        var ww = vc.getBoundingClientRect().width;
        if (ww > hh) {
          var vTag = document.getElementsByClassName("live-video");
          vTag.forEach((element) => {
            element.style.height = hh + "px";
          });
          var vcDiv = document.getElementsByClassName("vidDiv");
          vcDiv.forEach((element) => {
            element.style.height = hh + "px";
            element.style.width = (hh * 16) / 9 + "px";
          });
        } else {
          var vTag = document.getElementsByClassName("live-video");
          vTag.forEach((element) => {
            element.style.width = ww + "px";
          });
          var vcDiv = document.getElementsByClassName("vidDiv");
          vcDiv.forEach((element) => {
            element.style.width = ww + "px";
            element.style.height = (ww * 9) / 16 + "px";
          });
        }
      }, 1000);
    },
    newStart() {
      // Delete this cookie
      document.cookie = "cookieList" + "=; Max-Age=-99999999;";
      window.location.reload();
    },
    pickList() {
      //check if you have cookie before to play it directly
      let templist;
      if (
        document.cookie.match(new RegExp("(^| )" + "cookieList" + "=([^;]+)"))
      ) {
        templist = document.cookie.match(
          new RegExp("(^| )" + "cookieList" + "=([^;]+)")
        );
        // console.log(templist);
        templist = templist.splice(2, 2);
        templist = templist.toString().split(",");
        // console.log(templist);
        templist.forEach((element) => {
          this.selectedStreams.push(parseInt(element));
        });
        // this.mvResize();
        // console.log(listValues);
        // alreadyPicked();
        // mvPlay();
      }
    },
  },
};
</script>

<style>
/*  */
video {
  display: inline-block;
  margin: 0px;
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
.vidDiv {
  display: inline-block;
  margin: 0px;
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  object-fit: contain;
}
.vidContianer {
  /* height: 100%; */
  /* width: 100%; */
  display: inline-block;
}
.mainMV {
  display: flex;
  flex-flow: row wrap;
}
.mainMV1x1 {
  display: flex;
  flex-flow: row wrap;
}
.mainMV1x1 > :nth-child(n) {
  width: calc(100vw);
  height: calc(100vh);
}
.mainMV1x2 {
  display: flex;
  flex-flow: row wrap;
}
.mainMV1x2 > :nth-child(n) {
  width: calc(100vw / 2);
  height: calc(100vh);
}
.mainMV2x2 {
  display: flex;
  flex-flow: row wrap;
}
.mainMV2x2 > :nth-child(n) {
  width: calc(100vw / 2);
  height: calc(100vh / 2);
}
.mainMV2x3 {
  display: flex;
  flex-flow: row wrap;
}
.mainMV2x3 > :nth-child(n) {
  width: calc(100vw / 3);
  height: calc(100vh / 2);
}
.mainMV3x3 {
  display: flex;
  flex-flow: row wrap;
}
.mainMV3x3 > :nth-child(n) {
  width: calc(100vw / 3);
  height: calc(100vh / 3);
}
.mainMV3x4 {
  display: flex;
  flex-flow: row wrap;
}
.mainMV3x4 > :nth-child(n) {
  width: calc(100vw / 4);
  height: calc(100vh / 3);
}
.mainMV4x4 {
  display: flex;
  flex-flow: row wrap;
}
.mainMV4x4 > :nth-child(n) {
  width: calc(100vw / 4);
  height: calc(100vh / 4);
}
.overlay-info {
  position: sticky;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 5%;
  background-color: rgba(113, 27, 205, 0.358);
}
body {
  margin: 0;
  padding: 0;
  overflow: hidden; /* Hide scrollbars */
  background: black;
}
*,
::before,
::after {
  box-sizing: initial;
}
.vidContianer {
  height: 100%;
  width: 100%;
  position: relative;
}
.visualizer-container__bar {
  display: inline-block;
  background: rgb(123, 0, 255);
  margin: 0 1px;
  width: 25px;
}
#PlayersArea {
  background: rgb(0, 0, 0);
}
</style>

<style scoped lang="sass">
.live-video
  background: black
  // border: 5px solid #000
  // margin: 0.5vh 0.5vw
</style>